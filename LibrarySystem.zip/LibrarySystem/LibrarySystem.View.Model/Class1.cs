﻿using System;

namespace LibrarySystem.View.Model
{
    public class Class1
    {
    }
}
