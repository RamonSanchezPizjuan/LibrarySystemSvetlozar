﻿using System;

namespace LibrarySystem.Data
{
    public class Class1
    {
    }
}
