﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Data
{
   public class ConfirgurationData
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS; Database=LibrarySystem; Integrated Security = True;";
    }
}
