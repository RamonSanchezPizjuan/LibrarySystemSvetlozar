﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
    public class TitleService
    {
        private LibrarySystemDbContext context;
        public TitleService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int CreateTitle(string name, string description, string author, string isbn, string type, string publisher, int year, string image)
        {
            var titleObject = context.Titles.FirstOrDefault(x => x.TitleName == name);
            var title = new Title()
            {
                Name=name,
                Description=description,
                Author=author,
                ISBN=isbn,
                Type=type,
                Publisher=publisher,
                Year=year,
                Image=image
            };
            this.context.Titles.Add(title);
            titleObject.Titles.Add(title);
            return title.Id;
        }
    }
}
