﻿namespace LibrarySystem.Services
{
    internal class LibrarySystemDbContext
    {
        public object Titles { get; set; }
    }
}