﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
   public class UserService:IUserService
    {
        private LibrarySystemDbContext context;
        public UserService(LibrarySystemDbContext context)
        {
            this.context = context;
        }

        public int AddUser(string name, string password, string role, string email, string names)
        {
            throw new NotImplementedException();
        }

        public int CreateUser(string username, string password, string role, string email, string name)
        {
            var userObject = context.Titles.FirstOrDefault(x => x.Username == username);
            var user = new User()
            {
                Username=username,
                Password=password,
                Role=role,
                Email=email,
                Name=name
            };
            this.context.Users.Add(user);
            userObject.Users.Add(user);
            return user.Id;
        }
    }

    internal class User
    {
        public User()
        {
        }

        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
    }
}
