﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
    public class LibraryUnitService:ILibraryUnitService
    {
        private LibrarySystemDbContext context;
        public LibraryUnitService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int CreateLibraryUnit(string condition, string career, string storage, string title)
        {
            var titleObject = context.Titles.FirstOrDefault(x => x.TitleName == title);
            var libraryunit = new LibraryUnit()
            {
                Condition = condition,
                Career = career,
                Storage = storage,
                TitleId = titleObject.TitleId
            };
            this.context.LibraryUnits.Add(libraryunit);
            titleObject.LibraryUnits.Add(libraryunit);
            context.SaveChanges();
            return libraryunit.InventoryNumberId;
        }
    }
}
