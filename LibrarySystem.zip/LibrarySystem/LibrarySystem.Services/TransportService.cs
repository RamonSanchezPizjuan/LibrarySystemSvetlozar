﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
   public class TransportService:ITransportService
    {
        private LibrarySystemDbContext context;
        public TransportService (LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int CreateTransport(string type, string reader, string librarian, string condition)
        {
            var transportObject = context.Titles.FirstOrDefault(x => x.TransportName == type);
            var transport = new Transport()
            {
                Type = type,
                Reader = reader,
                librarian = librarian,
                Condition = condition
        };
            this.context.Transports.Add(transport);
            transportObject.Transports.Add(transport);
            context.SaveChanges();
            return transport.Id;
        }
    }
}
