﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
   public interface ILibraryUnitService
    {
        public int CreateLibraryUnit(string condition, string career, string storage, string title);
    }
}
