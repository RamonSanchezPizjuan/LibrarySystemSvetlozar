﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
   public interface ITitleService
    {
        public int AddTitle(string name, string description, string author, string isbn, string type, string image, string publisher, string section);
    }
}
