﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
   public interface ITransportService
    {
        public int CreateTransport(string type, string reader, string librarian, string condition);
    }
}
