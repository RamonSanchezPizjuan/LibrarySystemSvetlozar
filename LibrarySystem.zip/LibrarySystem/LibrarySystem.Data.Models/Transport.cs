﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibrarySystem.Data.Models
{
   public class Transport
    {
        public DateTime Date { get; set; }
        public DateTime Return { get; set; }
        public int Id { get; set; }
        public string Type { get; set; }
        public string Reader { get; set; }
        public string Librarian { get; set; }
        public string Condition { get; set; }
        public Transport()
        {
            this.Date = DateTime.UtcNow;
            this.Return = DateTime.UtcNow;
        }
    }
}
