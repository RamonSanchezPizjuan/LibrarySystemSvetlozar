﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibrarySystem.Data.Models
{
   public class Title
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public string Type { get; set; }
        public string Publisher { get; set; }
        public int Year { get; set; }
        public string Image { get; set; }
        public Section Section { get; set; }
        public ICollection<LibraryUnit> LibraryUnits { get; set; }
        public Title()
        {
            this.LibraryUnits = new List<LibraryUnit>();
        }
    }
}
