﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibrarySystem.Data.Models
{
   public class LibraryUnit
    {
        [Key]
        public int Id { get; set; }
        public Title Title { get; set; }
        public string Condition { get; set; }
        public string Career { get; set; }
        public string Storage { get; set; }
        public LibraryUnit() { }
    }
}
